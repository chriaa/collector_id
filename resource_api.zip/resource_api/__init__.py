# __init__.py
from .OrcidAPI import OrcidAPI
from .OpenAlexAPI import OpenAlexAPI

# need to run this: zip -r ../resource_api.zip ../resource_api/